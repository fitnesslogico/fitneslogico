# Fitness Lógico · Web V1 revisable

8 de octubre de 2026. Base: main a9377006ade947cb462a40807f5891349a290716.

## Cambios

- Tres páginas completas en HTML sin dependencia de framework ni nueva plataforma.
- Oferta única Plan Lógico 90 Días; $150.000 CLP, pago único por 90 días.
- Nuevas altas: evaluación y llamada inicial de hasta 30 minutos después del pago; entrega en 1–3 días tras pago e información completa; reporte semanal con devolución; evaluación cada 30 días, ajustes según necesidad; WhatsApp L–V dentro de un día hábil; revisión de cierre. Clientes actuales mantienen condiciones acordadas.
- Portada centrada en el visitante; proceso, ejemplo ilustrativo, biografía breve, condiciones, FAQ, recursos y contacto.
- Menú móvil con details nativo, FAQ con details, foco visible, etiquetas y errores asociados.
- Conservados index.html, calculadora.html, reto.html y el ancla #calculadora.
- Calculadoras integrada e independiente comparten exactamente el mismo módulo.
- Reto convertido deliberadamente desde HTML con React compilado a una página estática con siete días autoguiados. Se reemplazó el recurso completo, sin manipular internamente el bundle ni migrar el resto de la web. No se encontró fuente React separada; el original permanece en el commit base.
- Fotos existentes sin alteración de identidad. Versiones WebP pequeñas; no se afirma una mejora de velocidad sin medición.
- Logo definitivo pendiente de elección entre propuestas. La web usa un nombre tipográfico provisional, sin incorporar una opción como aprobada.

## Calculadora: fuentes, supuestos y límites

Fuente primaria comprobada: Mifflin et al., 1990, PMID 2305711, https://pubmed.ncbi.nlm.nih.gov/2305711/?format=pubmed. El artículo estudió adultos sanos de 19 a 78 años y publica las ecuaciones simplificadas 10W + 6.25H − 5A + 5 y 10W + 6.25H − 5A − 161. Se conserva esa ecuación existente.

Se limita la interfaz a 19–78 años por el alcance de la muestra original, no por afirmar que toda ecuación está clínicamente validada para todos en ese intervalo. Los límites técnicos de peso 35–200 kg y estatura 130–220 cm se conservan del sitio previo; no representan un rango clínico validado.

Factores 1.2, 1.375, 1.55, 1.725, 1.9 y ajustes de déficit −20% y superávit +15% se conservan como supuestos aproximados de la herramienta anterior. No provienen del artículo Mifflin. No se afirma que sean la mejor pauta universal ni que el cálculo mida gasto real. Reparto ilustrativo conservado: proteína 2.2/2.0/1.8 g/kg según objetivo; grasa 25%; carbohidrato residual. La posición ISSN 2017 (https://pmc.ncbi.nlm.nih.gov/articles/PMC5477153/) describe necesidades variables en adultos sanos que entrenan; no valida la combinación fija de esta herramienta para cualquier visitante. La fuente se consultó como contexto, no como certificación del reparto.

No se ajustaron estos parámetros por razones comerciales. Se muestran como ejemplos orientativos con supuestos visibles. Decisión conservadora: eliminar salidas automáticas de agua y fibra del recurso público hasta una revisión propia; no ofrecerlas como prescripción general. No se calculan pautas para menores, embarazo, lactancia o necesidades clínicas. No se guardan ni envían entradas.

Errores: valores vacíos, no finitos, fuera de rango, edad fraccionaria y selecciones inválidas; rechazo cuando el reparto requeriría carbohidratos negativos. Resultados anteriores se ocultan al editar o fallar. Gramos y calorías se redondean solo para mostrar; internamente los macros suman la energía objetivo.

## Verificación

- node --check en los dos scripts: aprobado.
- node docs/check-calculator.cjs: 851 casos, incluidos valores esperados, entradas inválidas y combinaciones extremas con coherencia energética.
- Tres páginas: archivos enlazados y anclas internas existentes, IDs sin duplicar, una H1 por documento, imágenes con texto alternativo y dimensiones, CTA con número y nombre uniformes, sin envío de formulario.
- Contraste calculado: texto principal/fondo 17.2:1; secundario/superficie 9.7:1; acento/superficie 7.6:1; botón blanco/azul 5.9:1.
- No se enviaron mensajes ni se abrieron conversaciones como prueba.
- No se instalaron rastreadores, formularios de captación ni servicios.

Límite: no se pudo efectuar revisión renderizada móvil/escritorio ni pruebas de interacción en navegador para la nueva versión con la infraestructura de vista previa disponible en esta ejecución. Los cambios de CSS y la estructura responsive no sustituyen esa revisión. Menú, foco, FAQ, estados de la calculadora y carga de imágenes deben verificarse en navegador antes de hacer merge.

## Publicación

La web actual usa GitHub Pages y main, con CNAME fitnesslogico.com. Esta rama es solo una propuesta; no hacer merge hasta revisar logo y vista renderizada. Antes de publicar, reconfirmar configuración Pages y base actual. Para volver atrás, revertir el commit incorporado y comprobar el despliegue. No modificar DNS o CNAME. El commit base conserva todos los archivos anteriores.

## Corrección de vista previa · 8 octubre

Se reemplazó el visor con iframe/srcdoc por un documento directo con navegación local entre paneles. Se evita navegación de anclas dentro de un contexto aislado y se abren los enlaces externos en la misma pestaña en la vista descargable. No se modificaron los números/perfiles destino. El controlador de calculadoras ahora inicializa cada instancia y localiza sus errores dentro de su formulario.

Prueba de integración DOM con jsdom: ambas calculadoras muestran 2.699 kcal para hombre, 44 años, 85 kg, 177 cm, actividad 1.55; ocultan resultados al editar y rechazan −1; anclas internas, cambio de páginas y control móvil verificados; sin excepciones JavaScript ni IDs duplicados. Esto verifica DOM/eventos, no renderizado visual ni apertura externa real. Los 851 casos matemáticos siguen aprobados.

## Corrección de calculadora y correo · V3

La calculadora utiliza un botón de acción directa, sin envío de formulario. Enter en un campo numérico también calcula. Resultados y errores se llevan a la zona visible. Pruebas de integración mediante clic real en el botón DOM: ambas instancias muestran 2.699 kcal con el caso de referencia; datos inválidos producen errores. Esto no sustituye la comprobación visual en el navegador del usuario.

Correo confirmado por Eduardo: contacto.edufitlogico@gmail.com. Se conserva mailto como apertura de la app configurada, se muestra la dirección y se incorpora Copiar correo con alternativa de selección de texto cuando el portapapeles no está disponible. La página no envía correos.
