const assert=require('node:assert/strict');
const {calculate}=require('../assets/calculator.js');
const base={sex:'hombre',age:44,weight:85,height:177,activity:1.55,goal:'mantenimiento'};
let count=0;
function check(data,expected){const result=calculate(data);assert.equal(result.ok,expected);count++;return result;}
const r=check(base,true);assert.equal(r.bmr,1741.25);assert.equal(r.tdee,2698.9375);assert.equal(r.protein,170);
for(const goal of ['mantenimiento','deficit','superavit'])for(const sex of ['hombre','mujer']){const x=check({...base,goal,sex},true);assert.ok(Math.abs(x.protein*4+x.fat*9+x.carbs*4-x.target)<1e-8);assert.ok(x.carbs>=0);}
for(const age of [-1,0,18,79,NaN,Infinity,'',null,44.5,'44bad'])check({...base,age},false);
for(const weight of [-5,0,34,201,NaN,Infinity,'',null])check({...base,weight},false);
for(const height of [-1,0,129,221,NaN,''])check({...base,height},false);
for(const activity of [0,1,1.6,Infinity,''])check({...base,activity},false);
check({...base,sex:'unknown'},false);check({...base,goal:'toString'},false);check({...base,goal:'__proto__'},false);
check({...base,sex:'mujer',age:78,weight:200,height:130,activity:1.2,goal:'deficit'},false);
check({...base,weight:'85.5',height:'177.5'},true);
for(const age of [19,44,78])for(const weight of [35,85,200])for(const height of [130,177,220])for(const activity of [1.2,1.375,1.55,1.725,1.9])for(const goal of ['mantenimiento','deficit','superavit'])for(const sex of ['hombre','mujer']){const x=calculate({age,weight,height,activity,goal,sex});if(x.ok){for(const key of ['bmr','tdee','target','protein','fat','carbs'])assert.ok(Number.isFinite(x[key])&&x[key]>=0);assert.ok(Math.abs(x.protein*4+x.fat*9+x.carbs*4-x.target)<1e-8);}else assert.ok(x.message||Object.keys(x.errors).length);count++;}
console.log(`${count} casos verificados: valores esperados, rechazo de entradas inválidas y coherencia energética.`);
